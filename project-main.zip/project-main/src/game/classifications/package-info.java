/**
 * Contains interfaces that are used to ensure the functionality of different groups of entities.
 */
package game.classifications;