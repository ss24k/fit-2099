package game.classifications;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * An interface used to ensure the correlation of purchasable entities
 */
public interface Purchasable {

    /**
     * Will complete the purchasing of an item
     * @param actor the actor that is purchasing the item
     * @return a string indicating the outcome of the purchase
     */
    String purchaseItem(Actor actor);

    /**
     * Will return a description of the purchase for the game menu
     * @return A string indicating what the purchase will achieve
     */
    String getVendorDescription();
}