package game.classifications;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * Base interface for items and grounds that can have an action taken on them.
 */
public interface Consumable {
    /**
     * Describe what action will be performed if this entity's ConsumeAction is chosen in the menu.
     *
     * @param actor The actor performing the action.
     * @return the action description to be displayed on the menu
     */
    String consumeDescription(Actor actor);

    /**
     * Perform the Action.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened (the result of the action being performed) that can be displayed to the user.
     */
    String execute(Actor actor, GameMap map);
}