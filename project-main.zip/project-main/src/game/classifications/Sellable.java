package game.classifications;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * An interface used to ensure the correlation of all Sellable classes
 */
public interface Sellable {

    /**
     * Will complete the selling of a Sellable entity
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string detailing the outcome of the purchase
     */
    String sellItem(Actor actor, GameMap map);

    /**
     * returns a description of the sale
     * @return a string detailing the potential transaction
     */
    String getSellerDescription();
}


