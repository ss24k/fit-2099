package game.actors;

import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.behaviours.AttackBehaviour;
import game.behaviours.WanderBehaviour;
import game.utility.Status;

/**
 * a class representing the hostile huntsman spider.
 */
public class HuntsmanSpider extends Enemy {
    /**
     * Constructor to add behaviours and capabilities.
     */
    public HuntsmanSpider() {
        super("Huntsman Spider", '8', 1);
        this.addBehaviour(0, new AttackBehaviour());
        this.addBehaviour(999, new WanderBehaviour());
        this.addCapability(Status.HOSTILE_TO_PLAYER);
    }


    /**
     * The huntsman spider attacks with one of its long legs.
     * @return the huntsman spider's IntrinsicWeapon.
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(1, "attacks with one of its long legs", 25);
    }



}
