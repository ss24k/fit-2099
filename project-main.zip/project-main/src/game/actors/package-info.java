/**
 * Contains actor classes
 */
package game.actors;