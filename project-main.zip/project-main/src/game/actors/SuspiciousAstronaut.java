package game.actors;

import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.behaviours.AttackBehaviour;
import game.behaviours.WanderBehaviour;
import game.utility.Status;

/**
 * A class to represent the Suspicious Astronaut actor in the game.
 */
public class SuspiciousAstronaut extends Enemy {

    /**
     * The constructor of the SuspiciousAstronaut class.
     *
     */
    public SuspiciousAstronaut() {
        super("Astronaut",'\u0D9E',99);
        this.addBehaviour(0, new AttackBehaviour());
        this.addBehaviour(999, new WanderBehaviour());
        this.addCapability(Status.HOSTILE_TO_PLAYER);
    }

    /**
     * A getter for the intrinsic weapon of the Suspicious Astronaut, with a variable damage amount.
     * @return The intrinsic weapon of the Suspicious Astronaut
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(Integer.MAX_VALUE, "attacks", 100);

    }

}
