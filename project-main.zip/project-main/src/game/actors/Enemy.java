package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.AttackAction;
import game.utility.Status;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;


/**
 * A class used to represent enemy actors
 */
public abstract class Enemy extends Actor{

    /**
     * the map containing the behaviours of the enemy actor
     */
    private Map<Integer, Behaviour> behaviours = new TreeMap<>();

    /**
     * The constructor of the NonPlayerActor class.
     *
     * @param name        the name of the NonPlayerActor
     * @param displayChar the character that will represent the NonPlayerActor in the display
     * @param hitPoints   the NonPlayerActor's starting hit points
     */
    public Enemy(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);

    }

    /**
     * The huntsman spider can be attacked by any actor that has the HOSTILE_TO_ENEMY capability
     *
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return           a list containing the action to attack the huntsman spider.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new AttackAction(this, direction));
        }
        return actions;
    }

    /**
     * Add a possible behaviour.
     * @param priority The priority of the behaviour, a lower value means it will be executed with higher priority.
     * @param behaviour The Behaviour.
     */
    public void addBehaviour(int priority, Behaviour behaviour) {
        this.behaviours.put(priority, behaviour);
    }

    /**
     * Get all behaviours in order of priority.
     * @return a collection of all behaviours in order of priority.
     */
    public Collection<Behaviour> getBehaviours() {
        return this.behaviours.values();
    }

    /**
     * At each turn, select a valid action to perform.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the valid action that can be performed in that iteration or null if no valid action is found
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        for (Behaviour behaviour : this.getBehaviours()) {
            Action action = behaviour.getAction(this, map);
            if(action != null)
                return action;
        }
        return new DoNothingAction();
    }


}
