package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;

import game.behaviours.FollowBehaviour;
import game.behaviours.StealBehaviour;
import game.behaviours.WanderBehaviour;
import game.utility.Ability;
import game.utility.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Class representing an AlienBug, a type of Enemy in the game.
 * AlienBug has a FollowBehaviour, StealBehaviour and WanderBehaviour.
 * AlienBug is also hostile to the player and can enter the ship.
 */
public class AlienBug extends Enemy {


    /**
     * Generates a random name for the AlienBug.
     * @return A string representing the name of the AlienBug.
     */
    private String getName(){
        Random random = new Random();
        return "Feature" + random.nextInt(9) + random.nextInt(9) + random.nextInt(9);
    }

    /**
     * Constructor to create an AlienBug with a FollowBehaviour, StealBehaviour and WanderBehaviour.
     * AlienBug is also hostile to the player and can enter the ship.
     */
    public AlienBug() {
        super("Feature" + (new Random()).nextInt(9) + (new Random()).nextInt(9) + (new Random()).nextInt(9), 'a', 2);
        this.addBehaviour(999, new WanderBehaviour());
        this.addBehaviour(998, new FollowBehaviour());
        this.addBehaviour(997, new StealBehaviour());
        this.addCapability(Status.HOSTILE_TO_PLAYER);
        this.addCapability(Ability.CAN_ENTER_SHIP);
    }

    /**
     * Determines the action that the AlienBug will take on its turn.
     * The AlienBug will first try to pick up any items at its current location.
     * If there are no items or after picking up an item, the AlienBug will try to follow the Player.
     * If the AlienBug cannot follow the Player, it will perform its default behaviour.
     *
     * @param actions    The actions available for this actor.
     * @param map        The map containing this actor.
     * @param display    The display where messages about actions are shown.
     * @return           The action this actor takes.
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return super.playTurn(actions, lastAction, map, display);
    }

    /**
     * Defines the actions to be taken when the AlienBug becomes unconscious.
     * The AlienBug will drop all its items and will be removed from the map.
     *
     * @param actor The actor that caused the AlienBug to become unconscious.
     * @param map The map containing the AlienBug.
     * @return A string describing the AlienBug's unconscious state.
     */
    @Override
    public String unconscious(Actor actor, GameMap map) {
        dropAllItems(map);
        map.removeActor(this);
        return this + " met their demise at the hand of " + actor;
    }

    /**
     * Drops all items in the AlienBug's inventory to its current location.
     *
     * @param map The map containing the AlienBug.
     */
    public void dropAllItems(GameMap map) {
        Location currentLocation = map.locationOf(this);
        List<Item> items = new ArrayList<>(this.getItemInventory());

        for (Item item : items) {
            this.removeItemFromInventory(item);
            currentLocation.addItem(item);
        }
    }
}