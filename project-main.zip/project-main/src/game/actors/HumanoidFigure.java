package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.utility.Status;

/**
 * A class that represents a humanoid figure in the game.
 * This figure has the capability to buy items.
 */
public class HumanoidFigure extends Actor {

    /**
     * Constructor to create a HumanoidFigure.
     * The humanoid figure is initialized with the capability to buy items.
     */
    public HumanoidFigure() {
        super("Humanoid", 'H', 99);
        this.addCapability(Status.BUYER);
    }

    /**
     * Determines the action that the HumanoidFigure will take on its turn.
     * The HumanoidFigure will do nothing on its turn.
     *
     * @param actions    The actions available for this actor.
     * @param lastAction The action this actor took last turn.
     * @param map        The map containing this actor.
     * @param display    The display where messages about actions are shown.
     * @return           The action this actor takes.
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }
}