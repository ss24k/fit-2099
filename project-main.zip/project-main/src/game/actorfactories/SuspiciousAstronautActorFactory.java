package game.actorfactories;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.SuspiciousAstronaut;

/**
 * A factory to generate new Suspicious Astronauts for spawn points
 */
public class SuspiciousAstronautActorFactory extends ActorFactory {

    /**
     * A constructor for the Suspicious astronaut factory class
     */
    public SuspiciousAstronautActorFactory() {
        super(0.05);
    }

    /**
     * Generates a new Suspicious Astronaut
     * @return a new Suspicious Astronaut
     */
    @Override
    public Actor generate() {
        return new SuspiciousAstronaut();
    }
}
