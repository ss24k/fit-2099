package game.actorfactories;

import edu.monash.fit2099.engine.actors.Actor;


/**
 * An interface to be implemented by factories used in the system
 */
public abstract class ActorFactory {

    /**
     * The rate at which the spawn points generate the non player actors
     */
    double spawnRate;

    /**
     * A constructor for the factory class
     * @param spawnRate The spawn rate of spawn points using this factory
     */
    public ActorFactory(double spawnRate){
        this.spawnRate = spawnRate;
    }

    /**
     * To be used to generate new Non player actors
     * @return A new non player actor
     */
    public abstract Actor generate();

    /**
     * a getter for the spawn rate of the non player actors spawn points
     * @return the spawn rate of the non player actors at spawn points
     */
    public double getSpawnRate(){
        return spawnRate;
    }
}
