package game.actorfactories;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.AlienBug;


/**
 * A factory to generate new Alien Bugs for spawn points
 */
public class AlienBugActorFactory extends ActorFactory {

    /**
     * A constructor for the Alien Bug Factory class
     */
    public AlienBugActorFactory() {
        super(0.1);
    }

    /**
     * generates a new alien bug
     * @return a new alien bug
     */
    @Override
    public Actor generate() {
        return new AlienBug();
    }
}
