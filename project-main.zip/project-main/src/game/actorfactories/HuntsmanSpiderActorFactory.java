package game.actorfactories;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.HuntsmanSpider;


/**
 * A factory to generate new Huntsman spiders for spawn points
 */
public class HuntsmanSpiderActorFactory extends ActorFactory {

    /**
     * A constructor for the huntsman spider factory class
     */
    public HuntsmanSpiderActorFactory() {
        super(0.05);
    }

    /**
     * generates a new huntsman spider
     * @return a new huntsman spider
     */
    @Override
    public Actor generate() {
        return new HuntsmanSpider();
    }
}
