package game.utility;

/**
 * Represent an ability of an actor.
 */
public enum Ability {
    /**
     * Can enter the interns ship
     */
    CAN_ENTER_SHIP,

}
