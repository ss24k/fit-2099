package game.utility;

/**
 * Represent a status/property of an actor.
 */
public enum Status {
    /**
     * Hostile to enemy actors.
     */
    HOSTILE_TO_ENEMY,
    /**
     * Hostile to the player.
     */
    HOSTILE_TO_PLAYER,

    /**
     * Can buy items from the actor
     */
    BUYER

}
