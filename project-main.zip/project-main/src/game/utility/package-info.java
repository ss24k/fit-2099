/**
 * Contains classes that provide useful features for the general operation of the code.
 */
package game.utility;