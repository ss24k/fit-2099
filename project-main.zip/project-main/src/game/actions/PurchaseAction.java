package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.classifications.Purchasable;

/**
 * A class representing the purchasing action
 */
public class PurchaseAction extends Action {

    /**
     * The item that the action will purchase
     */
    Purchasable item;

    /**
     * A constructor for the purchase action class
     * @param item The item that the action will purchase if executed
     */
    public PurchaseAction(Purchasable item){
        this.item = item;
    }

    /**
     * Executes the purchase action
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the string returned by the purchasables purchase item method, indicating whether the purchase was a success or a failure.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return item.purchaseItem(actor);
    }

    /**
     * Returns a description of the action for the menu of actions that the user will see
     * @param actor The actor performing the action.
     * @return a description of the purchase action
     */
    @Override
    public String menuDescription(Actor actor) {
        return item.getVendorDescription();
    }
}
