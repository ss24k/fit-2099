package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import java.util.List;
import java.util.Random;

/**
 * A class that represents a monologue action.
 * This action allows an actor to listen to a monologue.
 */
public class MonologueAction extends Action {

    /**
     * The list of monologue statements that may appear when the action is taken
     */
    private final List<String> monologueList;
    /**
     * A string containing the name of the source of the monologue
     */
    private String monologueSourceName;
    /**
     * Constructor to create a MonologueAction.
     * @param monologueList The list of monologues.
     */
    public MonologueAction(String monologueSourceName,List<String> monologueList) {
        this.monologueList = monologueList;
        this.monologueSourceName = monologueSourceName;
    }

    /**
     * Returns a description of this action to be displayed in the menu.
     * @param actor The actor performing the action.
     * @return A string describing the action, suitable for display in the menu.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " listens to " + monologueSourceName + "s monologue";
    }

    /**
     * Executes this action, making the actor listen to a random monologue from the list.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return A string describing the outcome of the action.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Random random = new Random();
        int randInt = random.nextInt(monologueList.size());
        return monologueList.get(randInt);
    }
}