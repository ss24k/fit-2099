package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.classifications.Sellable;

/**
 * A class to represent the selling action
 */
public class SellingAction extends Action {

    /**
     * The sellable item that the action will sell
     */
    Sellable item;

    /**
     * A constructor for the SellAction class
     * @param item The Sellable item that the action will sell
     */
    public SellingAction(Sellable item){
        this.item = item;
    }

    /**
     * Will execute the Selling action
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a string indicating the outcome of the selling action
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return item.sellItem(actor,map);
    }

    /**
     * Returns a description of the selling action for the user.
     * @param actor The actor performing the action.
     * @return a string with the menu description for the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return item.getSellerDescription();
    }
}
