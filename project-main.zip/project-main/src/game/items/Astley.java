package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.MonologueAction;
import game.classifications.Purchasable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Astley extends Item implements Purchasable {

    /**
     * A counter used to determine when the subscription is to be paid by the actor using Astleys services
     */
    private int counter = 5;

    /**
     * A boolean used to determine if the subscription currently active.
     */
    private boolean subscriptionActive;

    /**
     * A list of monologues always available to the player.
     */
    private final List<String> baseMonologueList;

    /**
     * A constructor of the Astley class
     */
    public Astley() {
        super("Astley\uD83E\uDD16", 'z', true);
        this.baseMonologueList = new ArrayList<>(Arrays.asList(
                "The factory will never gonna give you up, valuable intern!",
                "We promise we never gonna let you down with a range of staff benefits.",
                "We never gonna run around and desert you, dear intern!"
        ));
    }

    /**
     * Called when the item is purchased. Will determine if the actor has enough funds, and if so will add th item to the actors inventory.
     * @param actor the actor that is purchasing the item
     * @return A string detailing the outcome of the transaction.
     */
    @Override
    public String purchaseItem(Actor actor) {
        int price = 50;
        if (actor.getBalance() >= price) {
            actor.deductBalance(price);
            actor.addItemToInventory(this);
            return actor + " successfully purchased Astley";
        }
        return "purchase failed: insufficient funds";

    }

    public String getVendorDescription() {
        return "purchase Astley\uD83E\uDD16 for 50 credits";
    }

    /**
     * Returns an ActionList of Actions the user with this item in their inventory can carry out. This will include a monologue action.
     * @param owner the actor that owns the item
     * @return An ActionList with the actions the actor can take with this item.
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        List<String> monologues = new ArrayList<>(baseMonologueList);

        if (subscriptionActive) {
            if (owner.getItemInventory().size() > 10) {
                monologues.add("We never gonna make you cry with unfair compensation.");
            }
            if (owner.getBalance() > 50) {
                monologues.add("Trust is essential in this business. We promise we never gonna say goodbye to a valuable intern like you.");
            }
            if (owner.getAttribute(BaseActorAttributes.HEALTH) < 2) {
                monologues.add("Don't worry, we never gonna tell a lie and hurt you, unlike those hostile creatures.");
            }
            actions.add(new MonologueAction(this.toString(),monologues));
        }
        return actions;
    }

    /**
     * Will run every turn of the game, incrementing the counter and checking the balance of the intern every five turns to determine if the players subscription is still active.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        counter += 1;
        if (counter >= 5) {
            if (actor.getBalance() >= 1) {
                actor.deductBalance(1);
                subscriptionActive = true;
                counter = 0;
            } else {
                subscriptionActive = false;
            }
        }
    }
}
