package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.MoveActorAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.classifications.Purchasable;
import java.util.Random;

/**
 * A class representing a specific type of item, Theseus.
 * Theseus is a purchasable item that allows the actor to teleport.
 */
public class Theseus extends Item implements Purchasable {

    /**
     * Constructor for Theseus.
     */
    public Theseus() {
        super("Theseus", '^', true);
    }

    /**
     * Returns a list of actions that can be performed with this item when it is on the ground where the actor is standing. This will return the ability to teleport to a random location.
     * @param location the location of the item
     * @return a list of actions
     */
    @Override
    public ActionList allowableActions(Location location) {
        ActionList actions = new ActionList();
        Random random = new Random();
        Location destination;
        GameMap map = location.map();
        do {
            int x = random.nextInt(map.getXRange().max());
            int y = random.nextInt(map.getYRange().max());
            destination = map.at(x, y);
        } while (destination.containsAnActor());
        actions.add(new MoveActorAction(destination,"random location on current map using THESEUS"));
        return actions;
    }

    /**
     * Attempts to purchase this item for the actor.
     * If the actor has enough balance, the item is added to their inventory and the price is deducted from their balance.
     * @param actor the actor attempting to purchase the item
     * @return a message indicating the result of the purchase attempt
     */
    @Override
    public String purchaseItem(Actor actor) {
        int price = 100;
        if(actor.getBalance() >= price) {
            actor.deductBalance(price);
            actor.addItemToInventory(this);
            return actor + " successfully purchased Theseus";
        } else {
            return "purchase failed: insufficient funds";
        }
    }

    /**
     * Returns a description of this item for a vendor.
     * @return a vendor description
     */
    @Override
    public String getVendorDescription() {
        return "purchase Theseus for 100 credits";
    }
}