package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.classifications.Purchasable;
import game.actions.SellingAction;
import game.classifications.Sellable;
import game.utility.Status;

/**
 * A Toilet Paper Roll item that can be purchased from the Terminal.
 */
public class ToiletPaperRoll extends Item implements Purchasable, Sellable {


    /***
     * Constructor.
     */
    public ToiletPaperRoll() {
        super("ToiletPaperRoll \uD83E\uDDFB", 's', true);
    }


    /**
     * Called when the item is purchased
     * @param actor the actor that is purchasing the item
     * @return A string outlining the outcome of the transaction
     */
    @Override
    public String purchaseItem(Actor actor) {
        int price = 5;
        if (Math.random() <= 0.75) {
            System.out.println("COMPUTER TERMINAL ERROR: CHARGED 1 CREDIT");
            price = 1;
        }

        if (actor.getBalance() >= price) {
            actor.deductBalance(price);
            actor.addItemToInventory(this);
            return actor.toString() + " successfully purchased a toilet paper roll\uD83E\uDDFB";
        } else {
            return "Purchase failed: insufficient funds";
        }
    }

    /**
     * Generates a description of the purchase seen in the players menu
     * @return A string outlining the transaction.
     */
    @Override
    public String getVendorDescription() {
        return "purchase toilet paper\uD83E\uDDFB for 5 credits";
    }

    /**
     * Called to sell the item. Has a 50% chance of killing the actor instantly
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string outlining the outcome of the transaction.
     */
    @Override
    public String sellItem(Actor actor, GameMap map){
        int price = 1;
        if (Math.random()<=0.5) {
            actor.addBalance(price);
            actor.removeItemFromInventory(this);
            return actor + " successfully sold a toilet paper roll\uD83E\uDDFB for " + price + " credits.";
        } else {
            actor.unconscious(map);
            return "Haha, thats your end dude\uD83D\uDE07...the FACTORY HAS ENOUGH TOILET PAPER ROLL\uD83E\uDDFB...DIE\uD83D\uDC80";
        }
    }

    /**
     * Returns the description of the selling transaction
     * @return A string outlining the transaction
     */
    @Override
    public String getSellerDescription() {
        return "Sell toilet paper roll\uD83E\uDDFB for 1 credit.";
    }


    /**
     * Generates an ActionList containing the actions the actor can carry out when this item is in their inventory and the actor is in the soroundings of another actor. If in the surroundings of a buyer, a sell action is included.
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();


        if(otherActor.hasCapability(Status.BUYER)){
            actions.add(new SellingAction(this));
        }

        return actions;
    }

}


