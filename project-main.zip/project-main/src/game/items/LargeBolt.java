package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SellingAction;
import game.classifications.Sellable;
import game.utility.Status;

/**
 * Large bolt that can be picked up and dropped.
 */
public class LargeBolt extends Item implements Sellable {
    /**
     * Constructor.
     */
    public LargeBolt() {
        super("large bolt⚔\uFE0F", '+', true);
    }

    /**
     * Is called to sell the item to an actor
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string outlining the outcome of the sale.
     */
    @Override
    public String sellItem(Actor actor, GameMap map) {
        int price = 25;

        actor.addBalance(price);
        actor.removeItemFromInventory(this);
        return actor + " successfully sold a large bolt\uD83D\uDD29 for " + price + " credits.";
    }

    /**
     * Returns a description of the transaction.
     * @return A string describing the transaction.
     */
    @Override
    public String getSellerDescription() {
        return "Sell large bolts\uD83D\uDD29 for 25 credits.";
    }

    /**
     * Provides an ActionList containing the actions the user can take with this item. This will have a sell action if a buyer is within the sellers surroundings
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return an ActionList containing the actions the actor can carry each turn.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();

        if(otherActor.hasCapability(Status.BUYER)){
            actions.add(new SellingAction(this));
        }

        return actions;
    }
}