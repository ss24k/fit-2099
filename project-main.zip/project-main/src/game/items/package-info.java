/**
 * Contains item classes
 */
package game.items;