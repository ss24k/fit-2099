package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.ConsumeAction;
import game.classifications.Consumable;
import game.classifications.Purchasable;

/**
 * An Energy Drink item that can be consumed to heal the intern from attack consequences.
 */
public class EnergyDrink extends Item implements Consumable, Purchasable {

    /**
     * Constructor.
     */
    public EnergyDrink() {
        super("Energy drink\uD83D\uDD0B", '*', true);
    }

    /**
     * List of allowable actions that the healing item allows its owner to do. Call only when carried.
     * @param owner the actor that owns the item
     * @return a list containing the action to consume the item.
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Describe what action will be performed if this entity's ConsumeAction is chosen in the menu.
     *
     * @param actor The actor performing the action.
     * @return the description of the actor drinking the energy drink to be displayed on the menu
     */
    @Override
    public String consumeDescription(Actor actor) {
        return actor + " drinks " + this;
    }

    /**
     * Heals the actor and removes itself from the inventory.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened (the result of the actor drinking the energy drink) that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        int points = 1;
        actor.removeItemFromInventory(this);
        actor.heal(points);
        return actor + " drinks " + this + " for " + points + " health point.";
    }

    /**
     * Retrieves the Energy Drink item to be purchased.
     *
     * @return The Energy Drink item.
     */
    @Override
    public String purchaseItem(Actor actor) {
        int price = 10;
        if (Math.random() <= 0.2) {
            System.out.println("COMPUTER TERMINAL ERROR: CHARGED DOUBLE");
            price *= 2;
        }

        if(actor.getBalance() >= price) {
            actor.deductBalance(price);
            actor.addItemToInventory(this);
            return actor.toString() + " successfully purchased an energy drink\uD83D\uDD0B";
        } else {
            return "Purchase failed: insufficient funds";
        }
    }

    /**
     * Generates a description of the purchase that will be seen in the players menu.
     * @return A string outlining the transaction.
     */
    @Override
    public String getVendorDescription(){
        return "purchase energy drink\uD83D\uDD0B for 10 credits";
    }


}



