package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.classifications.Consumable;
import game.actions.SellingAction;
import game.classifications.Sellable;
import game.utility.Status;

import java.util.Random;

/**
 * Jar of Pickles that can be consumed for health with a chance of being expired.
 */
public class PickleJar extends Item implements Consumable, Sellable {

    /***
     * Constructor to set attributes.
     */
    public PickleJar() {
        super("jar of pickles\uD83E\uDED9", 'n', true);
    }

    /**
     * List of allowable actions that the healing item allows its owner to do. Call only when carried.
     * @param actor the actor that owns the item
     * @return a list containing the action to consume the item.
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();

        actions.add(new ConsumeAction(this));
        return actions;
    }


    /**
     * Describe what action will be performed if this entity's ConsumeAction is chosen in the menu.
     *
     * @param actor The actor performing the action.
     * @return the description of the actor eating from the jar of pickles to be displayed on the menu
     */
    @Override
    public String consumeDescription(Actor actor) {
        return actor + " eats from " + this;
    }

    /**
     * Heals or hurts the actor and removes itself from the inventory.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened (the result of the actor eating from the jar of pickles) that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Random random = new Random();
        int points;
        if (random.nextFloat() < 0.5) {
            points = -1;
        } else {
            points = 1;
        }

        actor.removeItemFromInventory(this);
        actor.heal(points);
        if (actor.getAttribute(BaseActorAttributes.HEALTH)==0) {
            actor.unconscious(map);
        }

        return actor + " eats from " + this + " for " + points + " health points.";
    }

    /**
     * A method called when the item is being sold.
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string outlining the outcome f the transaction
     */
    @Override
    public String sellItem(Actor actor, GameMap map) {
        int price = 25;
        if (Math.random() <= 0.5) {
            System.out.println("FACTORY ERROR: PAID DOUBLE");
            price *= 2;
        }

        actor.addBalance(price);
        actor.removeItemFromInventory(this);
        return actor + " successfully sold pickle jar\uD83E\uDED9 for " + price + " credits.";
    }

    /**
     * Returns a description the selling of the item
     * @return A string outlining the transaction
     */
    @Override
    public String getSellerDescription() {

        return "Sell pickle jars\uD83E\uDED9 for 25 credits.";
    }

    /**
     * Returns a ActionList with all the potential Actions the actor holding the item in their inventory can carry out with the item. Will have a sell action if in the surroundings of a buyer
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return An ActionList with the actions the actor can execute with this item at each given turn.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = super.allowableActions(otherActor,location);


        if(location.getActor().hasCapability(Status.BUYER)){
            actions.add(new SellingAction(this));
        }

        return actions;
    }
}