package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SellingAction;
import game.classifications.Sellable;
import game.utility.Status;


/**
 * Metal sheet that can be picked up and dropped.
 */
public class MetalSheet extends Item implements Sellable {
    /***
     * Constructor.
     */
    public MetalSheet() {
        super("metal sheet▨", '%', true);
    }

    /**
     * A method called when the item is being sold. has a 60% chance
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string outlining the outcome of the sale.
     */
    @Override
    public String sellItem(Actor actor, GameMap map) {
        int price = 20;
        if (Math.random() <= 0.6) {
            price /= 2;
            System.out.println("We've got plenty, but we'll buy it for half price");
        }

        actor.addBalance(price);
        actor.removeItemFromInventory(this);
        return actor + " successfully sold a metal sheet ▨ for " + price + " credits.";
    }

    /**
     * Returns a description of the sale
     * @return A string outlining the transaction
     */
    @Override
    public String getSellerDescription(){
        return "Sell metal sheet▨ for 20 credits";
    }


    /**
     * Generates an ActionList with the list of actions the that the actor holding the item can carry out. Will contain a sell action if in the surroundings of a buyer.
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return an ActionList with the available actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();


        if(otherActor.hasCapability(Status.BUYER)){
            actions.add(new SellingAction(this));
        }

        return actions;
    }
}