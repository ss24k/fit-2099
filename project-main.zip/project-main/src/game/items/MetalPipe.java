package game.items;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AttackAction;
import game.actions.SellingAction;
import game.classifications.Sellable;
import game.utility.Status;


/**
 * Metal pipe scrap that is portable and can be used as a weapon.
 */
public class MetalPipe extends WeaponItem implements Sellable {
    /**
     * Constructor to set name, display character, damage, verb and hit rate.
     */
    public MetalPipe() {
        super("metal pipe\uD83E\uDE88", '!', 1, "whacks", 20);
    }

    /**
     * Is called when the item is being sold.
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string detailing the outcome of the sale.
     */
    @Override
    public String sellItem(Actor actor, GameMap map) {
        int price = 35;

        actor.addBalance(price);
        actor.removeItemFromInventory(this);
        return actor + " successfully sold a metal pipe \uD83E\uDE88 for " + price + " credits.";
    }

    /**
     * Returns a description of the selling transaction.
     * @return A string detailing the transaction
     */
    @Override
    public String getSellerDescription() {
        return "Sell metal pipe \uD83E\uDE88 for 35 credits.";
    }

    /**
     * Generates a list of actions that the player can use when the item is in its inventory. Here you will have a sell option if a buyer is within the actors surroundings and an attack action if a hostile actor is in the actors surroundings.
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return An ActionList with the available actions for the actor holding the item in that turn.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = super.allowableActions(otherActor,location);


        if(location.getActor().hasCapability(Status.BUYER)){
                    actions.add(new SellingAction(this));
        }

        if(otherActor.hasCapability(Status.HOSTILE_TO_PLAYER)){
            actions.add(new AttackAction(otherActor,location.toString(),this));
        }

        return actions;
    }

}