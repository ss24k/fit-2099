package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AttackAction;
import game.classifications.Purchasable;
import game.utility.Status;


/**
 * Dragon Slayer Sword can be purchased from a computer terminal and used as a weapon.
 */
public class DragonSlayerSword extends WeaponItem implements Purchasable {

    /**
     * Constructor to set weapon item attributes.
     */
    public DragonSlayerSword() {
        super("Dragon Slayer Sword⚔\uFE0F", 'x', 50, "hits", 75);
    }


    public String purchaseItem(Actor actor){
        int price = 100;
        if (actor.getBalance() >= price) {
            actor.deductBalance(price);
            if(Math.random() <= 0.5) {
                return "COMPUTER TERMINAL ERROR: YOU AIN'T GETTING NOTHING SUCKER";
            } else {
                actor.addItemToInventory(this);
                return actor.toString() + " successfully purchase a dragon slayer sword⚔\uFE0F";
            }
        }
        return "purchase failed, insufficient funds";

    }
    /**
     * Provides a description of the item available for purchase from the vendor.
     *
     * @return A string describing the item ("dragon slayer sword ⚔️") and its cost (50 credits).
     */
    @Override
    public String getVendorDescription(){
        return "purchase dragon slayer sword ⚔\uFE0Ffor 50 credits";
    }

    /**
     * List of allowable actions that the weapon allows its owner to do to other actor. Call only when carried.
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return a list containing the action to attack the other actor.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location){
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_PLAYER)){
            actions.add(new AttackAction(otherActor,location.toString(),this));
        }
        return actions;
    }

}



