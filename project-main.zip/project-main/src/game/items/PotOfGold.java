package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.classifications.Consumable;
import game.actions.SellingAction;
import game.classifications.Sellable;
import game.utility.Status;

/**
 * Pot of gold scrap which can be found on the moon.
 * The intern can take the gold out of the pot to add 10 credits to their wallet.
 */
public class PotOfGold extends Item implements Consumable, Sellable {

    /**
     * The amount of gold in this jar
     */
    private final int goldAmount;

    /***
     * Constructor to instantiate a Pot of Gold object.
     */
    public PotOfGold(int goldAmount) {
        super("pot of gold\uD83D\uDCB0\uD83E\uDE99", '$', true);
        this.goldAmount = goldAmount;
    }

    /**
     * Generates a list of Actions the actor can carry out with this item in their inventory
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return An ActionList with the actions the actor can carry out with the item at each given turn of the game.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();


        if(location.getActor().hasCapability(Status.BUYER)){
            actions.add(new SellingAction(this));
        }

        return actions;
    }



    /**
     * Describe what action will be performed if this entity's ConsumeAction is chosen in the menu.
     *
     * @param actor The actor performing the action.
     * @return the description of the actor taking gold to be displayed on the menu
     */
    @Override
    public String consumeDescription(Actor actor) {
        return actor + " takes gold out of " + this;
    }

    /**
     * Adds credits to the actor and removes itself from the inventory.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened (the result of the actor taking gold) that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        actor.removeItemFromInventory(this);
        actor.addBalance(this.goldAmount);
        return actor + " takes gold out of " + this + " and adds " + this.goldAmount + " credits to their wallet.";
    }

    /**
     * A method called when the item is sold by an actor
     * @param actor The actor selling the item
     * @param map the map the item is being sold on
     * @return A string outlining the outcome of the transaction.
     */
    @Override
    public String sellItem(Actor actor, GameMap map) {
        int price = 500;
        if (Math.random() <= 0.25) {
            price = 0;
        }
        actor.addBalance(price);
        actor.removeItemFromInventory(this);
        return actor + " successfully sold a pot of gold \uD83D\uDCB0\uD83E\uDE99 for " + price + " credits.";
    }

    /**
     * Generates a description of the sale.
     * @return A string proposing the transaction.
     */
    @Override
    public String getSellerDescription() {
        return "Sell pot of gold \uD83D\uDCB0\uD83E\uDE99 for 500 credits";
    }

    /**
     * Returns a list of actions the actor can take with this item in their inventory. Will contain a consume action.
     * @param owner the actor that owns the item
     * @return a list of allowable actions
     */
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }


}