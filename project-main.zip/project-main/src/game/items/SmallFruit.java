package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.ConsumeAction;
import game.classifications.Consumable;

/**
 * Small fruit that can be picked up and dropped, and consumed for health.
 */
public class SmallFruit extends Item implements Consumable {
    /***
     * Constructor to set attributes.
     */
    public SmallFruit() {
        super("small fruit\uD83E\uDED0", 'o', true);
    }

    /**
     * List of allowable actions that the healing item allows its owner to do. Call only when carried.
     * @param owner the actor that owns the item
     * @return a list containing the action to consume the item.
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Describe what action will be performed if this entity's ConsumeAction is chosen in the menu.
     *
     * @param actor The actor performing the action.
     * @return the description of the actor eating the small fruit to be displayed on the menu
     */
    @Override
    public String consumeDescription(Actor actor) {
        return actor + " eats " + this;
    }

    /**
     * Heals the actor and removes itself from the inventory.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened (the result of the actor eating the small fruit) that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        int points = 1;
        actor.removeItemFromInventory(this);
        actor.heal(points);
        return actor + " eats " + this + " for " + points + " health point.";
    }
}