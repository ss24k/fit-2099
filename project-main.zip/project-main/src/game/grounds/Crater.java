package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;

import game.actorfactories.ActorFactory;
import java.util.Random;

/**
 * Base class for spawn points. Spawns actors.
 */
public class Crater extends Ground {

    /**
     * The chance of the crater spawning an actor
     */
    private double chance;

    /**
     * A random used to randomise whether an actor is spawned at each turn
     */
    private final Random random = new Random();

    /**
     * The factory that is used to generate the instances of actors to be spawned
     */
    ActorFactory factory;

    /**
     * Constructor to set actor and chance to spawn.
     *
     * @param factory the factory that generate the actors to be spawned
     */
    public Crater(ActorFactory factory) {
        super('u');
        this.chance = factory.getSpawnRate();
        this.factory = factory;
    }

    /**
     * Get a new instance of the actor to spawn.
     * @return a new instance of the actor to spawn.
     */
    public Actor getActor() {
        return factory.generate();
    };


    /**
     * Chance of spawning the actor.
     * @param location The location of the spawn point
     */
    @Override
    public void tick(Location location) {
        if (!location.containsAnActor() && this.random.nextFloat() < this.chance) {
            location.addActor(this.getActor());
        }
    }
}