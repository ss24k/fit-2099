package game.grounds;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.MoveActorAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.purchasefactories.PurchaseFactory;
import game.actions.PurchaseAction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A class that represents a computer terminal in the game.
 * This terminal allows an actor to purchase items and move to different locations.
 */
public class ComputerTerminal extends Ground {

    /**
     * A list to contain all the factories being used by the instance of computer terminal
     */
    private List<PurchaseFactory> factories = new ArrayList<>();
    /**
     * A map of all the map names to the locations that the player can travel to from the computer terminal
     */
    private Map<Location, String> locationMapNames = new HashMap<>();


    /**
     * Constructor to create a ComputerTerminal.
     */
    public ComputerTerminal() {
        super('=');
    }

    /**
     * Adds a factory to the list of factories.
     * @param factory The factory to be added.
     */
    public void addFactory(PurchaseFactory factory){
        this.factories.add(factory);
    }

    /**
     * Adds a location and its corresponding map name to the lists.
     * @param location The location to be added.
     * @param mapName The map name to be added.
     */
    public void addLocation(Location location, String mapName) {
        locationMapNames.put(location, mapName);
    }

    /**
     * Returns a list of actions that the actor can perform.
     * The actor can purchase items from the factories and move to different locations.
     * @param actor The actor performing the action.
     * @param location The location of the actor.
     * @param direction The direction of the action.
     * @return A list of actions that the actor can perform.
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList actions = new ActionList();
        for (PurchaseFactory factory : factories) {
            actions.add(new PurchaseAction(factory.generatePurchase()));
        }

        for (Location destination : locationMapNames.keySet()) {
            if (!destination.containsAnActor()) {
                actions.add(new MoveActorAction(destination, "to " + locationMapNames.get(destination) + "!"));
            }
        }

        return actions;
    }
}