package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.items.LargeFruit;

/**
 * Mature Inheritree dropping a large fruit.
 */
public class MatureInheritree extends Inheritree {
    /**
     * Constructor.
     *
     */
    public MatureInheritree() {
        super('T');
    }

    /**
     * Drop large fruit with 20% chance.
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.dropFruit(location, new LargeFruit(), 0.20);
    }
}