package game.grounds;

import edu.monash.fit2099.engine.positions.Location;

/**
 * Sprout Inheritree growing into sapling.
 */
public class SproutInheritree extends Inheritree {
    /**
     * Constructor.
     */
    public SproutInheritree() {
        super(',');
    }

    /**
     * Grow to sapling stage after 3 ticks.
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.grow(location, 3, new SaplingInheritree());
    }
}
