package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.items.SmallFruit;

/**
 * Sapling Inheritree dropping a small fruit and growing into a young Inheritree.
 */
public class SaplingInheritree extends Inheritree {
    /**
     * Constructor.
     *
     */
    public SaplingInheritree() {
        super('t');
    }

    /**
     * Drop small fruit with 30% chance and grow to young stage after 6 ticks.
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.dropFruit(location, new SmallFruit(), 0.30);
        super.grow(location, 6, new YoungInheritree());
    }
}