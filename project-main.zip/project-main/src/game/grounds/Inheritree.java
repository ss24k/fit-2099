package game.grounds;

import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;

import java.util.List;
import java.util.Random;

/**
 * Base class for Inheritrees. Represents trees that may drop a fruit or grow to a new stage.
 */
abstract public class Inheritree extends Ground {

    /**
     * A random used to randomise whether fruits are dropped and the exit that they are dropped
     */
    private final Random random = new Random();

    /**
     * The age of the inheritree
     */
    private double age = 0;

    /**
     * Constructor.
     *
     * @param displayChar character to display for this type of terrain
     */
    public Inheritree(char displayChar) {
        super(displayChar);
    }

    /**
     * Chance of dropping a fruit within the surroundings.
     * @param location The location of the fruiter.
     * @param chance THe chance to drop a fruit.
     */
    protected void dropFruit(Location location, Item fruit, double chance) {
        if (random.nextFloat() < chance) {
            List<Exit> exits = location.getExits();
            Exit exit = exits.get(random.nextInt(exits.size()));
            exit.getDestination().addItem(fruit);
        }
    }

    /**
     * Grow to a new stage after a certain number of ticks.
     * @param location The location of the Inheritree.
     * @param matureAge The number of ticks after which to grow to a new stage.
     * @param nextStage The stage to grow into.
     */
    protected void grow(Location location, int matureAge, Ground nextStage) {
        age++;
        if (age >= matureAge) {
            location.setGround(nextStage);
        }
    }
}