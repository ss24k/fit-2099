package game.grounds;

import edu.monash.fit2099.engine.positions.Location;

/**
 * Sprout Inheritree growing into a mature Inheritree.
 */
public class YoungInheritree extends Inheritree {
    /**
     * Constructor.
     */
    public YoungInheritree() {
        super('y');
    }

    /**
     * Grow to mature stage after 5 ticks.
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.grow(location, 5, new MatureInheritree());
    }
}
