package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import game.utility.Ability;
import game.utility.Status;

/**
 * Floor inside a building that actors hostile to the player cannot enter.
 */
public class Floor extends Ground {
    /**
     * Constructor to set display character.
     */
    public Floor() {
        super('_');
    }

    /**
     * Prevent hostile actors from entering the floor.
     * @param actor the Actor to check
     * @return true if the actor is non-hostile, or false if the actor is hostile to the player.
     */
    public boolean canActorEnter(Actor actor) {
        if (actor.hasCapability(Ability.CAN_ENTER_SHIP)) {
            return true;
        } else {
            return false;
        }
    }
}