package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;

/**
 * Wall that actors cannot enter.
 */
public class Wall extends Ground {
    /**
     * Constructor to set display character.
     */
    public Wall() {
        super('#');
    }

    /**
     * Prevent actors from entering the wall.
     * @param actor the Actor to check
     * @return false.
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
