package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;

/**
 * Bare dirt.
 */
public class Dirt extends Ground {
    /**
     * Constructor to set display character.
     */
    public Dirt() {
        super('.');
    }
}