package game.grounds;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.ActorAttributeOperations;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.classifications.Consumable;

/**
 * Puddle that can increase maximum health.
 */
public class Puddle extends Ground implements Consumable {
    /**
     * Constructor to set display character.
     */
    public Puddle() {
        super('~');
    }

    /**
     * List the actions that the puddle allows actors located on it to do.
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return a list containing the action to increase maximum health from the ground if the actor is located on this ground, otherwise an empty ActionList.
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList actions = new ActionList();
        if (direction.equals("")) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }

    /**
     * Describe what action will be performed if this entity's ConsumeAction is chosen in the menu.
     *
     * @param actor The actor performing the action.
     * @return the description of the actor drinking from the puddle to be displayed on the menu
     */
    @Override
    public String consumeDescription(Actor actor) {
        return actor + " drinks from puddle.";
    }

    /**
     * Adds to the actor's maximum health.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened (the result of the actor drinking from the puddle) that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        actor.modifyAttributeMaximum(BaseActorAttributes.HEALTH, ActorAttributeOperations.INCREASE, 1);
        return actor + " drinks from puddle to increase maximum health by 1 point.";
    }
}
