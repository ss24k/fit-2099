package game;

import game.actors.HumanoidFigure;
import game.actorfactories.AlienBugActorFactory;
import game.purchasefactories.AstleyFactory;
import game.purchasefactories.DragonSlayerSwordFactory;
import game.purchasefactories.EnergyDrinkFactory;
import game.actorfactories.HuntsmanSpiderActorFactory;
import game.actorfactories.SuspiciousAstronautActorFactory;
import game.purchasefactories.TheseusFactory;
import game.purchasefactories.ToiletPaperRollFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.World;
import game.actors.AlienBug;
import game.actors.HuntsmanSpider;
import game.actors.Player;
import game.grounds.*;
import game.items.*;




/**
 * The main class to start the game.
 */
public class Application {

    /**
     * Start the game.
     * @param args not required
     */
    public static void main(String[] args) {

        World world = new World(new Display());

        FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(),
                new Wall(), new Floor(), new Puddle(), new SproutInheritree(), new SaplingInheritree(), new YoungInheritree(), new MatureInheritree(), new ComputerTerminal());

        List<String> map = Arrays.asList(
                "...~~~~.........~~~...........",
                "...~~~~.......................",
                "...~~~........................",
                "..............................",
                ".............#####............",
                ".............#___#...........~",
                ".............#___#..........~~",
                ".............##_##.........~~~",
                ".........,....#~#~~........~~~",
                "................#~~~.......~~~",
                ".............~###~~~........~~",
                "......~.....~~~~~~~~.........~",
                ".....~~~...~~~~~~~~~..........",
                ".....~~~~~~~~~~~~~~~~........~",
                ".....~~~~~~~~~~~~~~~~~~~....~~");

        GameMap gameMap = new GameMap(groundFactory, map);
        world.addGameMap(gameMap);



        List<String> refactorioMap = Arrays.asList(
                "..........................~~~~",
                "..........................~~~~",
                "..........................~~~~",
                "~..........................~..",
                "~~...........#####............",
                "~~~..........#___#............",
                "~~~..........#___#............",
                "~~~..........##_##............",
                "~~~..................~~.......",
                "~~~~................~~~~......",
                "~~~~...............~~~~~......",
                "..~................~~~~.......",
                "....................~~........",
                ".............~~...............",
                "............~~~~.............."
        );

        GameMap refactorio = new GameMap(groundFactory, refactorioMap);
        world.addGameMap(refactorio);

        List<String> factoryMap = Arrays.asList(
                ".......",
                ".#####.",
                ".#___#.",
                ".#___#.",
                ".##_##.",
                ".......",
                ".......",
                ".......",
                ".......",
                "......."
        );

        GameMap factory = new GameMap(groundFactory, factoryMap);
        world.addGameMap(factory);



        for (String line : FancyMessage.TITLE.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        gameMap.at(7, 9).addActor(new HuntsmanSpider());



        HumanoidFigure humanoidFigure = new HumanoidFigure();
        factory.at(3,9).addActor(humanoidFigure);

        gameMap.at(10, 5).addItem(new LargeBolt());
        gameMap.at(20, 10).addItem(new LargeBolt());
        gameMap.at(20, 10).addItem(new MetalSheet());
        gameMap.at(15, 7).addItem(new MetalPipe());
        gameMap.at(15, 6).addItem(new PickleJar());
        gameMap.at(15, 6).addItem(new PickleJar());
        gameMap.at(15, 6).addItem(new PickleJar());
        gameMap.at(15, 6).addItem(new PickleJar());
        gameMap.at(15, 6).addItem(new PotOfGold(10));

        ArrayList<ComputerTerminal> terminals = new ArrayList<>();

        ComputerTerminal polymorphiaTerminal = new ComputerTerminal();
        polymorphiaTerminal.addLocation(factory.at(3, 3),"The Factory \uD83C\uDFED\uD83C\uDD7F\uFE0F");
        polymorphiaTerminal.addLocation(refactorio.at(15, 6),"Refactorio \uD83C\uDF11");
        gameMap.at(15,5).setGround(polymorphiaTerminal);
        terminals.add(polymorphiaTerminal);

        ComputerTerminal factoryTerminal = new ComputerTerminal();
        factoryTerminal.addLocation(gameMap.at(15, 6),"Polymorphia \uD83C\uDF11");
        factoryTerminal.addLocation(refactorio.at(15, 6),"Refactorio \uD83C\uDF11");
        factory.at(3,2).setGround(factoryTerminal);
        terminals.add(factoryTerminal);


        ComputerTerminal refactorioTerminal = new ComputerTerminal();
        refactorioTerminal.addLocation(gameMap.at(15,6),"Polymorphia \uD83C\uDF11");
        refactorioTerminal.addLocation(factory.at(3,3),"The Factory \uD83C\uDFED\uD83C\uDD7F\uFE0F");
        refactorio.at(15,5).setGround(refactorioTerminal);
        terminals.add(refactorioTerminal);

        for(ComputerTerminal terminal:terminals){
            terminal.addFactory(new DragonSlayerSwordFactory());
            terminal.addFactory(new EnergyDrinkFactory());
            terminal.addFactory(new ToiletPaperRollFactory());
            terminal.addFactory(new AstleyFactory());
            terminal.addFactory(new TheseusFactory());

        }
        refactorio.at(5,10).setGround(new SproutInheritree());
        refactorio.at(6,11).setGround(new SproutInheritree());
        refactorio.at(9,12).setGround(new SproutInheritree());
        gameMap.at(5,10).setGround(new Crater(new AlienBugActorFactory()));
        gameMap.at(5,11).setGround(new Crater(new HuntsmanSpiderActorFactory()));
        gameMap.at(5,12).setGround(new Crater(new SuspiciousAstronautActorFactory()));

        gameMap.at(7, 7).addItem(new PotOfGold(10));


        Player player = new Player("Intern", '@', 4);
        world.addPlayer(player, gameMap.at(15,6));


        gameMap.at(5,5).addActor(new AlienBug());
        gameMap.at(5,6).addItem(new MetalSheet());
        gameMap.at(4,6).addItem(new MetalSheet());
        gameMap.at(4,5).addItem(new MetalSheet());
        gameMap.at(6,5).addItem(new MetalSheet());

        player.addBalance(10000000);
        world.run();

        for (String line : FancyMessage.YOU_ARE_FIRED.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }
}