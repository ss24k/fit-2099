package game.purchasefactories;

import game.items.Astley;
import game.classifications.Purchasable;

/**
 * a factory to generate Astley for purchase via the computer terminal
 */
public class AstleyFactory extends PurchaseFactory {

    /**
     * Generates the new Astley item.
     * @return The new instance of Astley
     */
    @Override
    public Purchasable generatePurchase() {
        return new Astley();
    }
}
