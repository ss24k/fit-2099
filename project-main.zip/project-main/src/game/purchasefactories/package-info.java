/**
 * Contains purchase factory classes
 */
package game.purchasefactories;