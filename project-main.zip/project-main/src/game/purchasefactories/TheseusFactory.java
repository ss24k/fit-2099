package game.purchasefactories;

import game.items.Theseus;
import game.classifications.Purchasable;

/**
 * A factory for the Theseus item class
 */
public class TheseusFactory extends PurchaseFactory {

    /**
     * Generates a new instance of the Theseus item class
     * @return a new instance of theseus
     */
    @Override
    public Purchasable generatePurchase() {
        return new Theseus();
    }
}
