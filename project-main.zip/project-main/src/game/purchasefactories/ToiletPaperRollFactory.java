package game.purchasefactories;

import game.items.ToiletPaperRoll;
import game.classifications.Purchasable;

/**
 * A factory for the toilet paper roll item class
 */
public class ToiletPaperRollFactory extends PurchaseFactory {

    /**
     * Generates a new instance of the toilet paper roll item class
     * @return a new instance of toilet paper roll
     */
    @Override
    public Purchasable generatePurchase() {
        return new ToiletPaperRoll();
    }

}

