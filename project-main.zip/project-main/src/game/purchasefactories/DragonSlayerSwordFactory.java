package game.purchasefactories;

import game.items.DragonSlayerSword;
import game.classifications.Purchasable;

/**
 * A factory for the Dragon slayer sword item class
 */
public class DragonSlayerSwordFactory extends PurchaseFactory {

    /**
     * generates a new instance of dragon slayer sword
     * @return the new instance of dragon slayer sword
     */
    @Override
    public Purchasable generatePurchase() {
        return new DragonSlayerSword();
    }
}
