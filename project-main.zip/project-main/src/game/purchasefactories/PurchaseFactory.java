package game.purchasefactories;

import game.classifications.Purchasable;

/**
 * An abstract class used to represent the factories used to generate purchasable items
 */
public abstract class PurchaseFactory {

    /**
     * Generates a new instance of a purchasable item
     * @return a new instance of the purchasable item
     */
    public abstract Purchasable generatePurchase();

}
