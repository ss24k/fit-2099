package game.purchasefactories;

import game.items.EnergyDrink;
import game.classifications.Purchasable;

/**
 * A factory for the energy drink item class
 */
public class EnergyDrinkFactory extends PurchaseFactory {


    /**
     * generates a new instance of the energy drink class
     * @return the new instance of energy drink
     */
    @Override
    public Purchasable generatePurchase() {
        return new EnergyDrink();
    }
}
