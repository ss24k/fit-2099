package game.behaviours;


import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actions.MoveActorAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.utility.Status;

/**
 * Class representing a FollowBehaviour, a type of Behaviour in the game.
 * FollowBehaviour allows an Actor to follow a target Actor.
 */

public class FollowBehaviour implements Behaviour {

    /**
     * The target of the actor displaying this behaviour
     */
    private Actor target;


    /**
     * Constructor to create a FollowBehaviour with a target Actor.
     *
     *
     */

    public FollowBehaviour() {
    }


    /**
     * Determines the action that the Actor with this Behaviour will take.
     * The Actor will try to move to a location adjacent to the target Actor.
     *
     * @param actor The Actor with this Behaviour.
     * @param map   The map containing the Actor.
     * @return      A MoveActorAction to move the Actor to a location adjacent to the target, or null if no such location is available.
     */

    @Override
    public Action getAction(Actor actor, GameMap map) {


        for(Exit exit:map.locationOf(actor).getExits()){
            if(exit.getDestination().containsAnActor()){
                if(exit.getDestination().getActor().hasCapability(Status.HOSTILE_TO_ENEMY)){
                    this.target=exit.getDestination().getActor();
                }
            }
        }

        if(!map.contains(this.target) || !map.contains(actor)) {
            return null;
        }

        Location actorLocation = map.locationOf(actor);
        Location targetLocation = map.locationOf(this.target);

        int currentDistance = distance(actorLocation,targetLocation);

        for (Exit exit : actorLocation.getExits()) {
            Location destination = exit.getDestination();
            if (destination.canActorEnter(actor) && distance(destination, targetLocation) < currentDistance) {
                return new MoveActorAction(destination, exit.getName());
            }
        }
        return new DoNothingAction();
    }
    /**
     * Calculates the Manhattan distance between two locations.
     *
     * @param a The first location.
     * @param b The second location.
     * @return  The Manhattan distance between the two locations.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}