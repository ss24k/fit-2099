package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;

import game.actions.AttackAction;
import game.utility.Status;

import java.util.ArrayList;
import java.util.Random;

/**
 * Attack a creature not hostile to the player.
 */
public class AttackBehaviour implements Behaviour {


    /**
     * Constructor for the attack behaviour class
     */
    public AttackBehaviour() {
    }

    /**
     * Get an AttackAction to a random neighbour not hostile to the player.
     *
     * @param actor the Actor acting
     * @param map   the GameMap containing the Actor
     * @return an AttackAction, or null if no AttackAction is possible
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        ArrayList<Action> actions = new ArrayList<>();
        Random random = new Random();
        for (Exit exit : map.locationOf(actor).getExits()) {
            if (exit.getDestination().containsAnActor()) {
                Actor otherActor = exit.getDestination().getActor();

                if (otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
                    actions.add(new AttackAction(otherActor, exit.getName()));
                }
            }
        }

        if (!actions.isEmpty()) {
            return actions.get(random.nextInt(actions.size()));
        }

        return null;
    }
}
