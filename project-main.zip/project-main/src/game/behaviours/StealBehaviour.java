package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.items.PickUpAction;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;

import java.util.List;

/**
 * A class that represents the stealing behaviour of an actor.
 * This behaviour allows an actor to pick up an item from the current location.
 */
public class StealBehaviour implements Behaviour {

    /**
     * Returns an action that represents the actor picking up an item from the current location.
     * If there are no items at the current location, it returns null.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return An action representing the actor picking up an item, or null if there are no items.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location currentLocation = map.locationOf(actor);
        List<Item> items = currentLocation.getItems();

        // Check for items to pick up at current location
        if (!items.isEmpty()) {
            return new PickUpAction(items.get(0));
        }

        return null;
    }
}