# FIT2099 Assignment (Semester 1, 2024)
# Static Factory

[Contribution Logs Spreadsheet](https://docs.google.com/spreadsheets/d/1sBI-SUWlA0pNvQ5o3PHLhyrYvEJPYgjvWOSAXKSBY-s/edit?usp=sharing)